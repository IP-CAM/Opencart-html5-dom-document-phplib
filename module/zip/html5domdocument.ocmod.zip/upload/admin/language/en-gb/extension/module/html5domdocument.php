<?php

/*
@name     Html5domdocument
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  2.6.0
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/lib-html5domdocument
@licence  https://github.com/ocmod-space/lib-html5domdocument/blob/main/LICENSE.txt
*/

$_['heading_title'] = '#ocmod.space: html5domdocument';
$_['text_extension'] = 'Extensions';
$_['text_edit'] = 'Edit <b>Html5domdocument</b>';
$_['text_made'] = 'Made with <i class="fa fa-heart-o" aria-hidden="true" style=" background: -webkit-linear-gradient(#0066cc, #ffcc00); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i> in Ukraine';
$_['text_about'] = 'The module adds an HTML5 parser by <a target="_blank" href="https://github.com/ivopetkov/html5-dom-document-php">ivopetkov</a> to the OpenCart vendor library.';
